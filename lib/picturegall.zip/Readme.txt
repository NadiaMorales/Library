Picturegall

Para comenzar:

1.- Copie y pegue el archivo index en la carpeta de su proyecto

2.- Pegue este script en el html de su pryecto:

   <script src="index.js"></script>

Creando una galeria

 Para usar picturegall debe enlazar el script con el CDN en el index de su proyecto al final de la etiqueta body. 
 Debe colocar las imagenes con las que desee hacer su galeria dentro de un div con la clase gallery esta hara que 
 automaticamente sus imagenes se ordenen en cuadricula.

Tama�os de imagenes

 Las clases img-xs img-s img-m img-l img-xl, se le pueden dar distintos dimensiones a sus imagenes, 
 solo agregue estas clases dentro de la etiqueta img.

Hover

 Si desea agregar efecto a su imagen debe agregar a la misma clase imgZoom.

 Es importante seguir el orden para que su galeria sea optima como se muestra en el demo. 
 Tambien puede hacer un peque�o cambio de columnas estan predefinidas con 3 pero usted puede utilizarlas como lo desee. 
 El zoom se aplicara inmediatamente despues de agregar las imagenes al html llamando al la funcion.

Si tiene dudas sobre su uso puede ver el demo incluido.
